#include <QtCore/QObject>

class WebSocketTest: public QObject
{
    Q_OBJECT
private slots:
    void properties();
};
