#include <QtCore/QObject>

class HttpServerRequestRouterTest: public QObject
{
    Q_OBJECT
private slots:
    void mappings();
};
