#include <QtCore/QObject>

class HttpUpgradeRouterTest: public QObject
{
    Q_OBJECT
private slots:
    void mappings();
};
