#include <QtCore/QObject>

class HttpPluginServerTest: public QObject
{
    Q_OBJECT
private slots:
    void config();
};
