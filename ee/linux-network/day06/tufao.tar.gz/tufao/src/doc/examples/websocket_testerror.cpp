if (int(ws.error()))
    /* ... */;
